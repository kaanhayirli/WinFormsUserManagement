﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class FaturaListesiForm : Form
    {
        public FaturaListesiForm()
        {
            InitializeComponent();
            LoadFaturalar();
            btnOdenen.Click += btnOdenen_Click;
        }
        
        private void LoadFaturalar()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("Tur", "Fatura Tipi");
            dataGridView1.Columns.Add("Tutar", "Tutar");
            dataGridView1.Columns.Add("SonOdemeTarihi", "Son Tarih");
            dataGridView1.Columns.Add("Aciklama", "Açıklama");
            dataGridView1.Columns.Add("OdendiMi", "Ödendi mi?");

            string baglantiString = "Server=KAAN-PC;Database=UserDB;User Id=sa;Password=Aa123456!;TrustServerCertificate=True;";
            using (var baglanti = new SqlConnection(baglantiString))
            {
                baglanti.Open();
                var komut = new SqlCommand();
                komut.Connection = baglanti;
                komut.CommandText = "SELECT Tur, Tutar, SonOdemeTarihi, Aciklama, OdendiMi FROM Faturalar";
                var veriOkuyucu = komut.ExecuteReader();

        while (veriOkuyucu.Read())
        {
                string odendiMiText = "Hayır";
                if (veriOkuyucu["OdendiMi"] != null && Convert.ToBoolean(veriOkuyucu["OdendiMi"]) == true)
                {
                    odendiMiText = "Evet";
                }
                
                    dataGridView1.Rows.Add(
                    veriOkuyucu["Tur"].ToString(),
                    veriOkuyucu["Tutar"].ToString(),
                    Convert.ToDateTime(veriOkuyucu["SonOdemeTarihi"]).ToShortDateString(),
                    veriOkuyucu["Aciklama"].ToString(),odendiMiText);
            }
        }
        }

        private void btnOdenen_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen bir fatura seçin!");
                return;
            }
            var row = dataGridView1.SelectedRows[0];
            string faturaTipi = row.Cells["Tur"].Value.ToString();
            decimal tutar = Convert.ToDecimal(row.Cells["Tutar"].Value);
            string sonTarih = row.Cells["SonOdemeTarihi"].Value.ToString();

            string baglantiString = "Server=KAAN-PC;Database=UserDB;User Id=sa;Password=Aa123456!;TrustServerCertificate=True;";
            using (var baglanti = new SqlConnection(baglantiString))
            {
                baglanti.Open();
                var komut = new SqlCommand();
                komut.Connection = baglanti;
                komut.CommandText = "UPDATE Faturalar SET OdendiMi=1 WHERE Tur=@Tur AND Tutar=@Tutar AND SonOdemeTarihi=@SonOdemeTarihi";
                komut.Parameters.AddWithValue("@Tur", faturaTipi);
                komut.Parameters.AddWithValue("@Tutar", tutar);
                komut.Parameters.AddWithValue("@SonOdemeTarihi", DateTime.Parse(sonTarih));
                komut.ExecuteNonQuery();
            }
            MessageBox.Show("Fatura ödendi olarak işaretlendi.");
            LoadFaturalar();
        }
    }
}