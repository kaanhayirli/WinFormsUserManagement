﻿namespace WinFormsApp2
{
    partial class FaturaTakibiForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dataGridViewTakip;
        private System.Windows.Forms.Button btnYenile;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitle = new System.Windows.Forms.Label();
            dataGridViewTakip = new System.Windows.Forms.DataGridView();
            btnYenile = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(dataGridViewTakip)).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.Text = "Fatura Takibi";
            lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            lblTitle.Height = 40;
            lblTitle.ForeColor = System.Drawing.Color.DarkSlateGray;
            lblTitle.BackColor = System.Drawing.Color.WhiteSmoke;
            // 
            // dataGridViewTakip
            // 
            dataGridViewTakip.AllowUserToAddRows = false;
            dataGridViewTakip.AllowUserToDeleteRows = false;
            dataGridViewTakip.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewTakip.ColumnHeadersHeight = 29;
            dataGridViewTakip.Location = new System.Drawing.Point(10, 50);
            dataGridViewTakip.Name = "dataGridViewTakip";
            dataGridViewTakip.ReadOnly = true;
            dataGridViewTakip.RowHeadersWidth = 51;
            dataGridViewTakip.Size = new System.Drawing.Size(650, 280);
            dataGridViewTakip.TabIndex = 0;
            // 
            // FaturaTakibiForm
            // 
            ClientSize = new System.Drawing.Size(700, 400);
            Controls.Add(lblTitle);
            Controls.Add(dataGridViewTakip);
            Controls.Add(btnYenile);
            Name = "FaturaTakibiForm";
            Text = "Fatura Takibi";
            ((System.ComponentModel.ISupportInitialize)(dataGridViewTakip)).EndInit();
            ResumeLayout(false);
        }
    }
}