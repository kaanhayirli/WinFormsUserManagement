﻿namespace WinFormsApp2
{
    partial class KullaniciBilgileriForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView kullaniciTablosu;
        private System.Windows.Forms.Button btnSil;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            kullaniciTablosu = new DataGridView();
            btnSil = new Button();
            ((System.ComponentModel.ISupportInitialize)kullaniciTablosu).BeginInit();
            SuspendLayout();
            // 
            // kullaniciTablosu
            // 
            kullaniciTablosu.AllowUserToAddRows = false;
            kullaniciTablosu.AllowUserToDeleteRows = false;
            kullaniciTablosu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            kullaniciTablosu.ColumnHeadersHeight = 29;
            kullaniciTablosu.Location = new Point(10, 10);
            kullaniciTablosu.MultiSelect = false;
            kullaniciTablosu.Name = "kullaniciTablosu";
            kullaniciTablosu.ReadOnly = true;
            kullaniciTablosu.RowHeadersWidth = 51;
            kullaniciTablosu.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            kullaniciTablosu.Size = new Size(330, 150);
            kullaniciTablosu.TabIndex = 0;
            // 
            // btnSil
            // 
            btnSil.BackColor = Color.Red;
            btnSil.Location = new Point(85, 170);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(180, 35);
            btnSil.TabIndex = 1;
            btnSil.Text = "Seçili Kullanıcıyı Sil";
            btnSil.UseVisualStyleBackColor = false;
            btnSil.Click += btnSil_Click;
            // 
            // KullaniciBilgileriForm
            // 
            BackColor = Color.White;
            ClientSize = new Size(359, 217);
            Controls.Add(kullaniciTablosu);
            Controls.Add(btnSil);
            Name = "KullaniciBilgileriForm";
            ((System.ComponentModel.ISupportInitialize)kullaniciTablosu).EndInit();
            ResumeLayout(false);
        }
    }
}