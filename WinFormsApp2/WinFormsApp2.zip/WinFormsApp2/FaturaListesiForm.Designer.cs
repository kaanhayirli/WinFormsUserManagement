﻿namespace WinFormsApp2
{
    partial class FaturaListesiForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnOdenen;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnOdenen = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeight = 29;
            dataGridView1.Location = new Point(10, 10);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(650, 320);
            dataGridView1.TabIndex = 0;
            // 
            // btnOdenen
            // 
            btnOdenen.BackColor = Color.MediumSeaGreen;
            btnOdenen.Location = new Point(10, 340);
            btnOdenen.Name = "btnOdenen";
            btnOdenen.Size = new Size(220, 40);
            btnOdenen.TabIndex = 1;
            btnOdenen.Text = "Ödendi Olarak İşaretle";
            btnOdenen.UseVisualStyleBackColor = false;
            // 
            // FaturaListesiForm
            // 
            ClientSize = new Size(703, 388);
            Controls.Add(dataGridView1);
            Controls.Add(btnOdenen);
            Name = "FaturaListesiForm";
            Text = "Fatura Listesi";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }
    }
}